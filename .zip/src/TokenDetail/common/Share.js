import PropTypes from 'prop-types';
import { useState, useEffect } from 'react';
import { FacebookShareButton, TwitterShareButton } from "react-share";
import { FacebookIcon, TwitterIcon } from "react-share";
import {CopyToClipboard} from 'react-copy-to-clipboard';

// Material
import {
    styled, useTheme, useMediaQuery,
    Avatar,
    Button,
    Chip,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    IconButton,
    Link,
    Stack,
    Tooltip,
    Typography
} from '@mui/material';

import {
    Share as ShareIcon,
    Close as CloseIcon
} from '@mui/icons-material';

// Context
import { useContext } from 'react';
import { AppContext } from 'src/AppContext';

// Redux
import { useSelector } from "react-redux";
import { selectMetrics } from "src/redux/statusSlice";

// Iconify
import { Icon } from '@iconify/react';
import copyIcon from '@iconify/icons-fad/copy';

// Utils
import { fNumber } from 'src/utils/formatNumber';

// ----------------------------------------------------------------------

const ShareDialog = styled(Dialog) (({ theme }) => ({
    backdropFilter: 'blur(1px)',
    WebkitBackdropFilter: 'blur(1px)', // Fix on Mobile
    '& .MuiDialogContent-root': {
        padding: theme.spacing(2),
    },
    '& .MuiDialogActions-root': {
        padding: theme.spacing(1),
    },
}));
  
const ShareDialogTitle = (props) => {
    const { children, onClose, ...other } = props;

    return (
        <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
            {children}
            {onClose ? (
                <IconButton
                    aria-label="close"
                    onClick={onClose}
                    sx={{
                        position: 'absolute',
                        right: 8,
                        top: 8,
                        color: (theme) => theme.palette.grey[500],
                    }}
                >
                    <CloseIcon />
                </IconButton>
            ) : null}
        </DialogTitle>
    );
};

ShareDialogTitle.propTypes = {
    children: PropTypes.node,
    onClose: PropTypes.func.isRequired,
};

export default function Share({token}) {
    const theme = useTheme();
    const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
    const metrics = useSelector(selectMetrics);
    const { accountProfile, openSnackbar, darkMode } = useContext(AppContext);

    const [open, setOpen] = useState(false);

    const {
        name,
        ext,
        md5,
        exch,
    } = token;

    let user = token.user;
    if (!user) user = name;

    // const imgUrl = `/static/tokens/${md5}.${ext}`;
    const imgUrl = `https://s1.xrpl.to/token/${md5}`;
    const title = `${user} price today: ${name} to USD conversion, live rates, trading volume, historical data, and interactive chart`;
    const desc = `Access up-to-date ${user} prices, ${name} market cap, trading pairs, interactive charts, and comprehensive data from the leading XRP Ledger token price-tracking platform.`;
    const url = typeof window !== 'undefined' && window.location.href ? window.location.href : '';//webxtor SEO fix

    const handleClickOpen = () => {
        setOpen(true);
    };

    const handleClose = () => {
        setOpen(false);
    };

    return (
        <>            
            <IconButton
                sx={{
                    "& .MuiChip-icon": {
                        color: '#F6B87E'
                    },
                    borderRadius: '4px',
                    border: `1px solid ${darkMode ? '#616161' : '#bdbdbd'}`
                }}
                onClick={handleClickOpen}>
                <ShareIcon fontSize="small" />
            </IconButton>

            <ShareDialog
                fullScreen={fullScreen}
                onClose={handleClose}
                aria-labelledby="customized-dialog-title"
                open={open}
                sx={{zIndex: 1302}}
            >
                {/* <ShareDialogTitle id="customized-dialog-title" onClose={handleClose}>
                    {user}
                </ShareDialogTitle> */}

                {/* <DialogContent dividers> */}

                <DialogContent>
                    <Stack alignItems="center">
                        <Avatar
                            alt={user}
                            src={imgUrl}
                            sx={{ width: 64, height: 64, mt: 2 }}
                        />
                        <Typography variant="desc">{user}</Typography>
                        <Typography variant="desc" sx={{mt:2}} noWrap>Spread the word: Share with your friends and network</Typography>
                        <Typography variant="subtitle1" sx={{mt:1, mb:2}}>The current price of {user} is $ {fNumber(exch / metrics.USD)}!</Typography>
                        <Stack direction="row" spacing={2}>
                            <FacebookShareButton
                                url={url}
                                quote={title}
                                hashtag={"#"}
                                description={desc}
                            >
                                <FacebookIcon size={32} round />
                            </FacebookShareButton>
                            <TwitterShareButton
                                title={title}
                                url={url}
                                hashtag={"#"}
                            >
                                <TwitterIcon size={32} round />
                            </TwitterShareButton>
                        </Stack>

                        <Stack direction="row" alignItems="center">
                            <Link
                                underline="none"
                                color="inherit"
                                target="_blank"
                                href={url}
                                rel="noreferrer noopener nofollow"
                            >
                                {url}
                            </Link>
                            <CopyToClipboard text={url} onCopy={()=>openSnackbar('Copied!', 'success')}>
                                <Tooltip title={'Click to copy'}>
                                    <IconButton>
                                        <Icon icon={copyIcon} />
                                    </IconButton>
                                </Tooltip>
                            </CopyToClipboard>
                        </Stack>
                    </Stack>
                </DialogContent>
                <DialogActions>
                    <Button autoFocus onClick={handleClose}>
                        Close
                    </Button>
                </DialogActions>
            </ShareDialog>
        </>
    );
}
